package com.potatographicsff.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.os.StatFs
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import java.io.File

class MainActivity : Activity() {
    private lateinit var web: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(DeviceBridge(this), "AndroidDevice")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    class DeviceBridge(private val context: Context) {
        @JavascriptInterface
        fun getStats(): String {
            val out = JSONObject()
            try {
                val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
                val mem = android.app.ActivityManager.MemoryInfo()
                activityManager.getMemoryInfo(mem)
                out.put("ramTotal", mem.totalMem / 1024 / 1024)
                out.put("ramFree", mem.availMem / 1024 / 1024)

                val pids = intArrayOf(Process.myPid())
                val pss = activityManager.getProcessMemoryInfo(pids).firstOrNull()?.totalPss ?: 0
                out.put("appRam", pss / 1024)

                val battery = context.registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                val level = battery?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
                val scale = battery?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
                val temp = battery?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
                out.put("battery", if (level >= 0 && scale > 0) level * 100 / scale else -1)
                out.put("batteryTemp", if (temp >= 0) temp / 10.0 else -1)

                val stat = StatFs(context.filesDir.absolutePath)
                out.put("storageFree", stat.availableBytes / 1024 / 1024)
                out.put("storageTotal", stat.totalBytes / 1024 / 1024)

                val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
                val network = cm.activeNetwork
                val caps = if (network != null) cm.getNetworkCapabilities(network) else null
                val type = when {
                    caps == null -> "Offline"
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile data"
                    else -> "Connected"
                }
                out.put("network", type)

                if (Build.VERSION.SDK_INT >= 29) {
                    val pm = context.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
                    out.put("thermal", when (pm.currentThermalStatus) {
                        0 -> "Normal"
                        1 -> "Light"
                        2 -> "Moderate"
                        3 -> "High"
                        4 -> "Severe"
                        5 -> "Critical"
                        6 -> "Emergency"
                        else -> "Unknown"
                    })
                } else out.put("thermal", "Not supported")
            } catch (e: Exception) {
                out.put("error", e.message ?: "Unavailable")
            }
            return out.toString()
        }

        @JavascriptInterface
        fun openGame(key: String): String {
            val packages = when (key) {
                "freefire" -> listOf("com.dts.freefireth", "com.dts.freefiremax")
                "pubg" -> listOf("com.tencent.ig", "com.pubg.imobile")
                "cod" -> listOf("com.activision.callofduty.shooter")
                "ml" -> listOf("com.mobile.legends")
                else -> emptyList()
            }
            for (pkg in packages) {
                val launch = context.packageManager.getLaunchIntentForPackage(pkg)
                if (launch != null) {
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(launch)
                    return "OPENING"
                }
            }
            return "NOT_INSTALLED"
        }

        @JavascriptInterface fun openBatterySettings() {
            context.startActivity(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        @JavascriptInterface fun openNetworkSettings() {
            context.startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        @JavascriptInterface fun openAppSettings() {
            context.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                android.net.Uri.parse("package:${context.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }
}
