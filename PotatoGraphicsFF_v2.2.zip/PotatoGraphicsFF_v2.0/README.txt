POTATO GRAPHICS FF v2.0

Android project for a simple offline Free Fire settings guide.

Build in GitHub Actions:
1. Upload the CONTENTS of this project folder to the root of your GitHub repository.
2. Keep .github/workflows/build-apk.yml in the repository.
3. Open the Actions tab and run the workflow (or push a commit).
4. Download the APK from the workflow run's Artifacts section.

The workflow uses GitHub's hosted Android SDK. Java 17 and Gradle 8.7 are used.

This app is only a settings guide. It does not modify game files, inject cheats,
unlock FPS, or promise performance improvements.
