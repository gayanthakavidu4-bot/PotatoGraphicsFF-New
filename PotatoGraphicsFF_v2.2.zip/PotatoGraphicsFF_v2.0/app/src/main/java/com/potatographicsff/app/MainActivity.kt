package com.potatographicsff.app

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Bundle
import android.os.Debug
import android.os.Process
import android.os.StatFs
import android.os.SystemClock
import android.os.PowerManager
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject

class MainActivity : Activity() {

    private var lastCpuTime = 0L
    private var lastElapsedTime = 0L

    inner class DeviceInfo {

        @JavascriptInterface
        fun openGame(gameKey: String): String {
            val games = mapOf(
                "freefire" to listOf(
                    "com.dts.freefireth",
                    "com.dts.freefiremax"
                ),
                "pubg" to listOf(
                    "com.tencent.ig",
                    "com.pubg.imobile"
                ),
                "cod" to listOf(
                    "com.activision.callofduty.shooter"
                ),
                "ml" to listOf(
                    "com.mobile.legends"
                )
            )

            val packages = games[gameKey] ?: return "UNKNOWN_GAME"

            for (packageName in packages) {
                val launchIntent =
                    packageManager.getLaunchIntentForPackage(packageName)

                if (launchIntent != null) {
                    runOnUiThread {
                        try {
                            startActivity(launchIntent)
                        } catch (e: Exception) {
                            // Launch may be unavailable on this device.
                        }
                    }
                    return "OPENING"
                }
            }

            return "NOT_INSTALLED"
        }

        @JavascriptInterface
        fun getStats(): String {
            val result = JSONObject()

            try {
                val manager =
                    getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager

                val memory = ActivityManager.MemoryInfo()
                manager.getMemoryInfo(memory)

                val totalRam = memory.totalMem / 1048576
                val freeRam = memory.availMem / 1048576

                val cpuTime = Process.getElapsedCpuTime()
                val elapsed = SystemClock.elapsedRealtime()

                var cpuUsage = 0.0

                if (lastElapsedTime > 0 && elapsed > lastElapsedTime) {
                    val cpuDiff = cpuTime - lastCpuTime
                    val timeDiff = elapsed - lastElapsedTime

                    cpuUsage = (cpuDiff.toDouble() / timeDiff * 100.0)
                        .coerceIn(0.0, 100.0)
                }

                lastCpuTime = cpuTime
                lastElapsedTime = elapsed

                result.put("totalRam", totalRam)
                result.put("freeRam", freeRam)
                result.put("usedRam", totalRam - freeRam)
                result.put("appRam", Debug.getPss() / 1024)
                result.put("appCpu", cpuUsage)

                val battery = registerReceiver(
                    null,
                    android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED)
                )

                if (battery != null) {
                    result.put("batteryLevel",
                        battery.getIntExtra("level", -1))
                    result.put("batteryTemp",
                        battery.getIntExtra("temperature", -1) / 10.0)
                }

                val stat = StatFs(filesDir.absolutePath)
                result.put("storageTotal",
                    stat.totalBytes / 1073741824.0)
                result.put("storageFree",
                    stat.availableBytes / 1073741824.0)

                val connectivity =
                    getSystemService(Context.CONNECTIVITY_SERVICE)
                        as ConnectivityManager

                val network = connectivity.activeNetwork
                val capabilities = if (network != null) {
                    connectivity.getNetworkCapabilities(network)
                } else null

                result.put("networkConnected", capabilities != null)
                result.put("wifi",
                    capabilities?.hasTransport(
                        NetworkCapabilities.TRANSPORT_WIFI
                    ) == true)
                result.put("cellular",
                    capabilities?.hasTransport(
                        NetworkCapabilities.TRANSPORT_CELLULAR
                    ) == true)

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val power =
                        getSystemService(Context.POWER_SERVICE) as PowerManager
                    result.put("thermalStatus", power.currentThermalStatus)
                } else {
                    result.put("thermalStatus", -1)
                }

                result.put("success", true)

            } catch (e: Exception) {
                result.put("success", false)
                result.put("error", e.message ?: "Unknown error")
            }

            return result.toString()
        }

        @JavascriptInterface
        fun openAppSettings() {
            runOnUiThread {
                val intent =
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                intent.data =
                    android.net.Uri.parse("package:$packageName")
                startActivity(intent)
            }
        }

        @JavascriptInterface
        fun openBatterySettings() {
            runOnUiThread {
                try {
                    startActivity(
                        Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)
                    )
                } catch (e: Exception) {
                    startActivity(Intent(Settings.ACTION_SETTINGS))
                }
            }
        }

        @JavascriptInterface
        fun openNetworkSettings() {
            runOnUiThread {
                startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val webView = WebView(this)
        webView.webViewClient = WebViewClient()
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.addJavascriptInterface(DeviceInfo(), "AndroidDevice")

        webView.loadUrl("file:///android_asset/index.html")
        setContentView(webView)
    }
}
